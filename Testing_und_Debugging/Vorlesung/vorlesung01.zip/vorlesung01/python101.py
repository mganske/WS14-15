# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

# Hack um Pyton3 verhalten zu simulieren
from __future__ import division, print_function, generators
old_range = range
range = xrange

# <codecell>

# Anzeigeformat bearbeiten
from IPython.core.display import HTML
HTML(open('./example.css', ).read())

# <headingcell level=1>

# Python 101

# <markdowncell>

# Für *Testing und Debugging* werden wir **Python 3.2**.

# <headingcell level=2>

# Zahlen

# <markdowncell>

# The interpreter acts as a simple calculator: you can type an expression at it and it will write the value. Expression syntax is straightforward: the operators +, -, * and / work just like in most other languages (e.g., Pascal or C); parentheses can be used for grouping. For example:

# <codecell>

>>> 2+2

# <codecell>

>>> # This is a comment
... 2+2

# <codecell>

>>> 2+2  # and a comment on the same line as code

# <codecell>

>>> (50-5*6)/4

# <markdowncell>

# ###Achtung
# ####Python 2:
# 
# `a / b` liefert Ganzzahldivision, wenn `a` *und* `b` ganzzahlig sind!
# 
# `a / b`  liefert Fließkommadivision, wenn `a` *oder* `b` Fließkommazahlen sind!
# 
# #####Beispiel:
# 
# `2 / 3` liefert `0`
# `2 / 3.` liefert `0.6666666666666666`
# 
# ####Python 3:
# 
# `a / b` liefert *immer* Fließkommadivision.

# <codecell>

>>> # Integer division returns the floor:
... 7//3

# <codecell>

>>> 7//-3

# <markdowncell>

# Like in C, the equal sign ("=") is used to assign a value to a variable. The value of an assignment is not written:

# <codecell>

>>> width = 20
>>> height = 5*9
>>> width * height

# <markdowncell>

# A value can be assigned to several variables simultaneously:

# <codecell>

>>> x = y = z = 0  # Zero x, y and z

# <codecell>

>>> x

# <codecell>

>>> y

# <codecell>

>>> z

# <markdowncell>

# There is full support for floating point; operators with mixed type operands convert the integer operand to floating point:

# <codecell>

>>> 4 * 2.5 / 3.3

# <codecell>

>>> 7.0 / 2

# <markdowncell>

# Complex numbers are also supported; imaginary numbers are written with a suffix of "j" or "J". Complex numbers with a nonzero real component are written as "(real+imagj)", or can be created with the "complex(real, imag)" function.

# <codecell>

>>> 1j * 1J

# <codecell>

>>> 1j * complex(0,1)

# <codecell>

>>> 3+1j*3

# <codecell>

>>> (3+1j)*3

# <codecell>

>>> (1+2j)/(1+1j)

# <markdowncell>

# Complex numbers are always represented as two floating point numbers, the real and imaginary part. To extract these parts from a complex number z, use z.real and z.imag.

# <codecell>

>>> a=1.5+0.5j

# <codecell>

>>> a.real

# <codecell>

>>> a.imag

# <markdowncell>

# The conversion functions to floating point and integer (float(), int() and long()) don't work for complex numbers -- there is no one correct way to convert a complex number to a real number. Use abs(z) to get its magnitude (as a float) or z.real to get its real part.

# <codecell>

>>> a=1.5+0.5j

# <codecell>

>>> float(a)

# <codecell>

>>> a.real

# <codecell>

>>> abs(a)

# <markdowncell>

# In interactive mode, the last printed expression is assigned to the variable _. This means that when you are using Python as a desk calculator, it is somewhat easier to continue calculations, for example:

# <codecell>

>>> tax = 17.5 / 100

# <codecell>

>>> price = 3.50

# <codecell>

>>> price * tax

# <codecell>

>>> price + _

# <codecell>

>>> round(_, 2)

# <markdowncell>

# This variable should be treated as read-only by the user. Don't explicitly assign a value to it -- you would create an independent local variable with the same name masking the built-in variable with its magic behavior.

# <headingcell level=2>

# Strings

# <markdowncell>

# Besides numbers, Python can also manipulate strings, which can be expressed in several ways. They can be enclosed in single quotes or double quotes:

# <codecell>

>>> 'spam eggs'

# <codecell>

>>> 'doesn\'t'

# <codecell>

>>> "doesn't"

# <codecell>

>>> '"Yes," he said.'

# <codecell>

>>> "\"Yes,\" he said."

# <codecell>

>>> '"Isn\'t," she said.'

# <markdowncell>

# String literals can span multiple lines in several ways. Newlines can be escaped with backslashes, e.g.:

# <codecell>

hello = "This is a rather long string containing\n\
several lines of text just as you would do in C.\n\
    Note that whitespace at the beginning of the line is\
 significant.\n"

# <codecell>

print(hello)

# <markdowncell>

# which would print the following:
# 
#     This is a rather long string containing
#     several lines of text just as you would do in C.
#         Note that whitespace at the beginning of the line is significant.
# 
# Or, strings can be surrounded in a pair of matching triple-quotes: """ or '''. End of lines do not need to be escaped when using triple-quotes, but they will be included in the string.

# <codecell>

print ("""
Usage: thingy [OPTIONS] 
     -h                        Display this usage message
     -H hostname               Hostname to connect to
""")

# <markdowncell>

# produces the following output:
# 
#     Usage: thingy [OPTIONS] 
#          -h                        Display this usage message
#          -H hostname               Hostname to connect to
# 
# The interpreter prints the result of string operations in the same way as they are typed for input: inside quotes, and with quotes and other funny characters escaped by backslashes, to show the precise value. The string is enclosed in double quotes if the string contains a single quote and no double quotes, else it's enclosed in single quotes. (The print statement, described later, can be used to write strings without quotes or escapes.)
# 
# Strings can be concatenated (glued together) with the + operator, and repeated with *:

# <codecell>

>>> word = 'Help' + 'A'

# <codecell>

>>> word

# <codecell>

>>> '<' + word*5 + '>'

# <markdowncell>

# Two string literals next to each other are automatically concatenated; the first line above could also have been written "word = 'Help' 'A'"; this only works with two literals, not with arbitrary string expressions.
# 
# Strings can be subscripted (indexed); like in C, the first character of a string has subscript (index) 0. There is no separate character type; a character is simply a string of size one. Like in Icon, substrings can be specified with the slice notation: two indices separated by a colon.

# <codecell>

>>> word[4]

# <codecell>

>>> word[0:2]

# <codecell>

>>> word[2:4]

# <markdowncell>

# Slice indices have useful defaults; an omitted first index defaults to zero, an omitted second index defaults to the size of the string being sliced.

# <codecell>

>>> word[:2]    # The first two characters

# <codecell>

>>> word[2:]    # All but the first two characters

# <markdowncell>

# Here's a useful invariant of slice operations: s[:i] + s[i:] equals s.

# <codecell>

>>> word[:2] + word[2:]

# <codecell>

>>> word[:3] + word[3:]

# <markdowncell>

# Degenerate slice indices are handled gracefully: an index that is too large is replaced by the string size, an upper bound smaller than the lower bound returns an empty string.

# <codecell>

>>> word[1:100]

# <codecell>

>>> word[10:]

# <codecell>

>>> word[2:1]

# <markdowncell>

# Indices may be negative numbers, to start counting from the right. For example:

# <codecell>

>>> word[-1]     # The last character

# <codecell>

>>> word[-2]     # The last-but-one character

# <codecell>

>>> word[-2:]    # The last two characters

# <codecell>

>>> word[:-2]    # All but the last two characters

# <markdowncell>

# But note that -0 is really the same as 0, so it does not count from the right!

# <codecell>

>>> word[-0]     # (since -0 equals 0)

# <markdowncell>

# Out-of-range negative slice indices are truncated, but don't try this for single-element (non-slice) indices:

# <codecell>

>>> word[-100:]

# <codecell>

>>> word[-10]    # error

# <markdowncell>

# The best way to remember how slices work is to think of the indices as pointing between characters, with the left edge of the first character numbered 0. Then the right edge of the last character of a string of n characters has index n, for example:
# 
#      +---+---+---+---+---+ 
#      | H | e | l | p | A |
#      +---+---+---+---+---+ 
#      0   1   2   3   4   5 
#     -5  -4  -3  -2  -1
# 
# The first row of numbers gives the position of the indices 0...5 in the string; the second row gives the corresponding negative indices. The slice from i to j consists of all characters between the edges labeled i and j, respectively.
# 
# For nonnegative indices, the length of a slice is the difference of the indices, if both are within bounds, e.g., the length of word[1:3] is 2.
# 
# The built-in function len() returns the length of a string:

# <codecell>

>>> s = 'supercalifragilisticexpialidocious'

# <codecell>

>>> len(s)

# <headingcell level=2>

# Lists

# <markdowncell>

# Python knows a number of compound data types, used to group together other values. The most versatile is the list, which can be written as a list of comma-separated values (items) between square brackets. List items need not all have the same type.

# <codecell>

>>> a = ['spam', 'eggs', 100, 1234]

# <codecell>

>>> a

# <markdowncell>

# Like string indices, list indices start at 0, and lists can be sliced, concatenated and so on:

# <codecell>

>>> a[0]

# <codecell>

>>> a[3]

# <codecell>

>>> a[-2]

# <codecell>

>>> a[1:-1]

# <codecell>

>>> a[:2] + ['bacon', 2*2]

# <codecell>

>>> 3*a[:3] + ['Boe!']

# <markdowncell>

# Unlike strings, which are immutable, it is possible to change individual elements of a list:

# <codecell>

>>> a

# <codecell>

>>> a[2] = a[2] + 23

# <codecell>

>>> a

# <markdowncell>

# Assignment to slices is also possible, and this can even change the size of the list:

# <codecell>

>>> # Replace some items:
... a[0:2] = [1, 12]

# <codecell>

>>> a

# <codecell>

>>> # Remove some:
... a[0:2] = []

# <codecell>

>>> a

# <codecell>

>>> # Insert some:
... a[1:1] = ['bletch', 'xyzzy']

# <codecell>

>>> a

# <codecell>

>>> a[:0] = a     # Insert (a copy of) itself at the beginning

# <codecell>

>>> a

# <markdowncell>

# The built-in fun_ction len() also applies to lists:

# <codecell>

>>> len(a)

# <markdowncell>

# It is possible to nest lists (create lists containing other lists), for example:

# <codecell>

>>> q = [2, 3]

# <codecell>

>>> p = [1, q, 4]

# <codecell>

>>> len(p)

# <codecell>

>>> p[1]

# <codecell>

>>> p[1][0]

# <codecell>

>>> p[1].append('xtra')     # See section 5.1

# <codecell>

>>> p

# <codecell>

>>> q

# <headingcell level=2>

# if Statements

# <markdowncell>

# Perhaps the most well-known statement type is the if statement. For example:

# <codecell>

x = 42

# <codecell>

>>> if x < 0:
...      x = 0
...      print('Negative changed to zero')
... elif x == 0:
...      print('Zero')
... elif x == 1:
...      print('Single')
... else:
...      print('More')

# <markdowncell>

# There can be zero or more elif parts, and the else part is optional. The keyword `elif` is short for `else if`, and is useful to avoid excessive indentation. An if ... elif ... elif ... sequence is a substitute for the switch or case statements found in other languages.

# <headingcell level=2>

# for Statements

# <markdowncell>

# The for statement in Python differs a bit from what you may be used to in C or Pascal. Rather than always iterating over an arithmetic progression of numbers (like in Pascal), or leaving the user completely free in the iteration test and step (as C), Python's for statement iterates over the items of any sequence (e.g., a list or a string), in the order that they appear in the sequence. For example (no pun intended):

# <codecell>

>>> # Measure some strings:
... a = ['cat', 'window', 'defenestrate']

# <codecell>

>>> for x in a:
...     print (x, len(x))

# <markdowncell>

# It is not safe to modify the sequence being iterated over in the loop (this can only happen for mutable sequence types, i.e., lists). If you need to modify the list you are iterating over, e.g., duplicate selected items, you must iterate over a copy. The slice notation makes this particularly convenient:

# <codecell>

>>> for x in a[:]: # make a slice copy of the entire list
...    if len(x) > 6:
...        a.insert(0, x)

# <codecell>

>>> a

# <headingcell level=2>

# The range() Function

# <markdowncell>

# If you do need to iterate over a sequence of numbers, the built-in function range() comes in handy. It generates arithmetic progressions:

# <codecell>

>>> for i in range(5):
...     print(i)

# <markdowncell>

# The given end point is never part of the generated sequence; range(10) generates 10 values, the legal indices for items of a sequence of length 10. It is possible to let the range start at another number, or to specify a different increment (even negative; sometimes this is called the ‘step’):
# 
#     range(5, 10)
#        5 through 9
# 
#     range(0, 10, 3)
#        0, 3, 6, 9
# 
#     range(-10, -100, -30)
#       -10, -40, -70
# 
# To iterate over the indices of a sequence, you can combine range() and len() as follows:

# <codecell>

>>> a = ['Mary', 'had', 'a', 'little', 'lamb']
>>> for i in range(len(a)):
...     print(i, a[i])

# <markdowncell>

# In most such cases, however, it is convenient to use the enumerate() function, see Looping Techniques.
# 
# A strange thing happens if you just print a range:
#     >>> print(range(10))
#     range(0, 10)

# <markdowncell>

# In many ways the object returned by range() behaves as if it is a list, but in fact it isn’t. It is an object which returns the successive items of the desired sequence when you iterate over it, but it doesn’t really make the list, thus saving space.
# 
# We say such an object is iterable, that is, suitable as a target for functions and constructs that expect something from which they can obtain successive items until the supply is exhausted. We have seen that the for statement is such an iterator. The function list() is another; it creates lists from iterables:

# <codecell>

>>> list(range(5))

# <headingcell level=2>

# break and continue Statements, and else Clauses on Loops

# <markdowncell>

# The break statement, like in C, breaks out of the smallest enclosing for or while loop.
# 
# Loop statements may have an else clause; it is executed when the loop terminates through exhaustion of the list (with for) or when the condition becomes false (with while), but not when the loop is terminated by a break statement. This is exemplified by the following loop, which searches for prime numbers:

# <codecell>

>>> for n in range(2, 10):
...     for x in range(2, n):
...         if n % x == 0:
...             print(n, 'equals', x, '*', n//x)
...             break
...     else:
...         # loop fell through without finding a factor
...         print(n, 'is a prime number')

# <markdowncell>

# (Yes, this is the correct code. Look closely: the else clause belongs to the for loop, not the if statement.)
# 
# When used with a loop, the else clause has more in common with the else clause of a try statement than it does that of if statements: a try statement’s else clause runs when no exception occurs, and a loop’s else clause runs when no break occurs. For more on the try statement and exceptions, see Handling Exceptions.
# 
# The continue statement, also borrowed from C, continues with the next iteration of the loop:

# <codecell>

>>> for num in range(2, 10):
...     if num % 2 == 0:
...         print("Found an even number", num)
...         continue
...     print("Found a number", num)

# <headingcell level=2>

# pass Statements

# <markdowncell>

# The pass statement does nothing. It can be used when a statement is required syntactically but the program requires no action. For example:

# <codecell>

>>> while True:
...     pass  # Busy-wait for keyboard interrupt (Ctrl+C)

# <markdowncell>

# This is commonly used for creating minimal classes:

# <codecell>

>>> class MyEmptyClass:
...     pass

# <markdowncell>

# Another place pass can be used is as a place-holder for a function or conditional body when you are working on new code, allowing you to keep thinking at a more abstract level. The pass is silently ignored:

# <codecell>

>>> def initlog(*args):
...     pass   # Remember to implement this!

# <headingcell level=2>

# Defining Functions

# <markdowncell>

# We can create a function that writes the Fibonacci series to an arbitrary boundary:

# <codecell>

>>> def fib(n):    # write Fibonacci series up to n
...     """Print a Fibonacci series up to n."""
...     a, b = 0, 1
...     while a < n:
...         print(a, end=' ')
...         a, b = b, a+b
...     print()

# <codecell>

>>> # Now call the function we just defined:
... fib(2000)

# <markdowncell>

# The keyword def introduces a function definition. It must be followed by the function name and the parenthesized list of formal parameters. The statements that form the body of the function start at the next line, and must be indented.
# 
# The first statement of the function body can optionally be a string literal; this string literal is the function’s documentation string, or docstring. (More about docstrings can be found in the section Documentation Strings.) There are tools which use docstrings to automatically produce online or printed documentation, or to let the user interactively browse through code; it’s good practice to include docstrings in code that you write, so make a habit of it.
# 
# The execution of a function introduces a new symbol table used for the local variables of the function. More precisely, all variable assignments in a function store the value in the local symbol table; whereas variable references first look in the local symbol table, then in the local symbol tables of enclosing functions, then in the global symbol table, and finally in the table of built-in names. Thus, global variables cannot be directly assigned a value within a function (unless named in a global statement), although they may be referenced.
# 
# The actual parameters (arguments) to a function call are introduced in the local symbol table of the called function when it is called; thus, arguments are passed using call by value (where the value is always an object reference, not the value of the object). [1] When a function calls another function, a new local symbol table is created for that call.
# 
# A function definition introduces the function name in the current symbol table. The value of the function name has a type that is recognized by the interpreter as a user-defined function. This value can be assigned to another name which can then also be used as a function. This serves as a general renaming mechanism:

# <codecell>

>>> fib

# <codecell>

>>> f = fib

# <codecell>

>>> f(100)

# <markdowncell>

# Coming from other languages, you might object that fib is not a function but a procedure since it doesn’t return a value. In fact, even functions without a return statement do return a value, albeit a rather boring one. This value is called None (it’s a built-in name). Writing the value None is normally suppressed by the interpreter if it would be the only value written. You can see it if you really want to using print():

# <codecell>

>>> fib(0)
>>> print(fib(0))

# <markdowncell>

# It is simple to write a function that returns a list of the numbers of the Fibonacci series, instead of printing it:

# <codecell>

>>> def fib2(n): # return Fibonacci series up to n
...     """Return a list containing the Fibonacci series up to n."""
...     result = []
...     a, b = 0, 1
...     while a < n:
...         result.append(a)    # see below
...         a, b = b, a+b
...     return result

# <codecell>

>>> f100 = fib2(100)    # call it
>>> f100                # write the result

# <markdowncell>

# This example, as usual, demonstrates some new Python features:
# 
# - The return statement returns with a value from a function. return without an expression argument returns None. Falling off the end of a function also returns None.
# - The statement result.append(a) calls a method of the list object result. A method is a function that ‘belongs’ to an object and is named obj.methodname, where obj is some object (this may be an expression), and methodname is the name of a method that is defined by the object’s type. Different types define different methods. Methods of different types may have the same name without causing ambiguity. (It is possible to define your own object types and methods, using classes, see Classes) The method append() shown in the example is defined for list objects; it adds a new element at the end of the list. In this example it is equivalent to result = result + [a], but more efficient.

# <codecell>


