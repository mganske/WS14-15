# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <headingcell level=1>

# Spezifikation

# <markdowncell>

# Die MyQueue Klasse stellt eine FIFO Warteschlange mit fester Länge für Integers bereit.
# 
# Der Konstruktor hat eine Parameter: Ein Integer > 0 der die maximale Anzahl von Elementen angibt, die die Warteschlange speichern kann.
# 
# - *`enqueue(i)`* versucht den Integer Wert `i` in der Warteschlange abzulegen.
#   Die Funktion gibt *True* zurück, falls dieser Versuch erfolgreich war und False wenn die Warteschlange voll ist.
# 
# - *`dequeue()`* entfernt (nach dem FIFO Prinzip) eine Wert aus der Warteschlange und gibt diesen zurück. 
#   Ist die Warteschlange leer, so wird *None* zurück gegeben.
# 
# - *`empty()`* gibt genau dann *True* zurück, wenn die Warteschlange keine Elemente enthält.
# 
# - *`full()`* gibt genau dann *True* zurück, wenn die Warteschlange kein weiters Element speichern kann.

# <codecell>

import array

class MyQueue:
    def __init__(self,size_max):
        assert size_max > 0
        self.max = size_max
        self.head = 0
        self.tail = 0
        self.size = 0
        self.data = array.array('i', range(size_max))

    def empty(self):
        return self.size == 0

    def full(self):
        return self.size == self.max

    def enqueue(self,x):
        if self.size == self.max:
            return False
        self.data[self.tail] = x
        self.size += 1
        self.tail += 1
        if self.tail == self.max:
            self.tail = 0
        return True

    def dequeue(self):
        if self.size == 0:
            return None
        x = self.data[self.head]
        self.size -= 1
        self.head += 1
        if self.head == self.max:
            self.head = 0
        return x

# <headingcell level=2>

# Zum Verstehen der Funktionen, hier ein kleines Beispiel:

# <codecell>

q = MyQueue(3)
r1 = q.enqueue(5)
r2 = q.enqueue(9)
r3 = q.enqueue(2)
r4 = q.enqueue(4)
r5 = q.dequeue()
r6 = q.dequeue()
r7 = q.dequeue()
r8 = q.dequeue()

# <headingcell level=2>

# Was erwarten Sie für die Werte von r1 - r8?

# <markdowncell>

# (a) **5, 9, 2, 4, 5, 9, 2, 4**  
# 
# (b) **True, True, True, True, 5, 9, 2, False**  
# 
# (c) **True, True, True, False, 5, 9, 2, 4**  
# 
# (d) **True, True, True, False, 5, 9, 2, None**  

# <codecell>

print(r1, r2, r3, r4, r5, r6, r7, r8)

# <codecell>


# <markdowncell>

# ### Und damit haben wir schon unseren ersten Test!
# ____

# <headingcell level=2>

# Was haben wir von diesem Test gelernt?

# <headingcell level=3>

# Welche der folgenden Aussagen sind wahr?

# <markdowncell>

# (a) Der Code hat diesen eine Testfall bestanden.  
# 
# (b) Der Code besteht jeden Testfall, in dem wir die 9 mit einer beliebigen ganzen Zahl ersetzen. 
# 
# (c) Der Code besteht viele Testfälle, in denen wir die 9 mit einer beliebigen ganzen Zahl ersetzen.
# 
# ___

# <headingcell level=2>

# Testfunktionen

# <codecell>

def test1():
    q = MyQueue(3)
    
    res = q.empty()
    if not res:
        print("test1 NOT OK")
        return
    
    res = q.enqueue(10)
    if not res:
        print("test1 NOT OK")
        return
    
    res = q.enqueue(11)
    if not res:
        print("test1 NOT OK")
        return
    
    x = q.dequeue()
    if x != 10:
        print("test1 NOT OK")
        return
    
    x = q.dequeue()
    if x != 11:
        print("test1 NOT OK")
        return
    
    res = q.empty()
    if not res:
        print("test1 NOT OK")
        return
    
    print("test1 OK")

# <codecell>

test1()

# <codecell>


# <headingcell level=3>

# Was haben wir getestet?

# <markdowncell>

# ___

# <headingcell level=2>

# Prüfen des "tail" Zeigers:

# <codecell>

def test2():
    q = MyQueue(2)
    
    res = q.empty()
    if not res:
        print("test2 NOT OK")
        return
    
    res = q.enqueue(1)
    if not res:
        print("test2 NOT OK")
        return
    
    res = q.enqueue(2)
    if not res:
        print("test2 NOT OK")
        return
    
    res = q.enqueue(3)
    if q.tail != 0:
        print("test2 NOT OK")
        return
    
    print("test2 OK")

# <codecell>

test2()

# <codecell>


# <markdowncell>

# ____

# <headingcell level=2>

# Prüfen des "head" Zeigers:

# <codecell>

def test3():
    q = MyQueue(1)

    res = q.empty()
    if not res:
        print("test3 NOT OK")
        return
    
    x = q.dequeue()
    if not x is None:
        print ("test3 NOT OK")
        return
    
    res = q.enqueue(1)
    if not res:
        print("test3 NOT OK")
        return
    
    x = q.dequeue()
    if x != 1 or q.head != 0:
        print("test3 NOT OK")
        return
    
    print("test3 OK")

# <codecell>

test3()

# <codecell>


# <markdowncell>

# ____
# ### Zurück zu den Folien
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .
# 
# .

# <headingcell level=1>

# Code abhärten: Die "checkRep" Funktion

# <markdowncell>

# Diese Funktion hat in einer Datenstruktur die Aufgabe zu prüfen, ob die Kombination aller Attribute eine gültige Konfiguration für die Datenstruktur darstellen.
# 
# Beginnen wir zunächst mit einem Einfachen Beispiel und konzentrieren wir uns darauf, dass der Wert für ```self.size``` stets innerhalb des gültigen Intervalls von ```0``` bis ```size.max``` liegt.

# <codecell>

def checkRep(self):
    assert self.size >= 0 and self.size <= self.max

# Eine neue Methode zur Klasse hinzufügen
MyQueue.checkRep = checkRep

# <headingcell level=2>

# Benutze die vorherigen Tests mit der `checkRep` Funktion

# <codecell>

def test1():
    q = MyQueue(3)
    q.checkRep()
    
    res = q.empty()
    q.checkRep()
    if not res:
        print("test1 NOT OK")
        return
    
    res = q.enqueue(10)
    q.checkRep()
    if not res:
        print("test1 NOT OK")
        return
    
    res = q.enqueue(11)
    q.checkRep()
    if not res:
        print("test1 NOT OK")
        return
    
    x = q.dequeue()
    q.checkRep()
    if x != 10:
        print("test1 NOT OK")
        return
    
    x = q.dequeue()
    q.checkRep()
    if x != 11:
        print("test1 NOT OK")
        return
    
    res = q.empty()
    q.checkRep()
    if not res:
        print("test1 NOT OK")
        return
    
    print("test1 OK")

# <codecell>

def test2():
    q = MyQueue(2)
    q.checkRep()
    
    res = q.empty()
    q.checkRep()
    if not res:
        print("test2 NOT OK")
        return
    
    res = q.enqueue(1)
    q.checkRep()
    if not res:
        print("test2 NOT OK")
        return
    
    res = q.enqueue(2)
    q.checkRep()
    if not res:
        print("test2 NOT OK")
        return
    
    res = q.enqueue(3)
    q.checkRep()
    if q.tail != 0:
        print("test2 NOT OK")
        return
    
    print("test2 OK")

# <codecell>

def test3():
    q = MyQueue(1)
    q.checkRep()

    res = q.empty()
    q.checkRep()
    if not res:
        print("test3 NOT OK")
        return
    
    x = q.dequeue()
    q.checkRep()
    if not x is None:
        print ("test3 NOT OK")
        return
    
    res = q.enqueue(1)
    q.checkRep()
    if not res:
        print("test3 NOT OK")
        return
    
    x = q.dequeue()
    q.checkRep()
    if x != 1 or q.head != 0:
        print("test3 NOT OK")
        return
    
    print("test3 OK")

# <codecell>

test1()
test2()
test3()

# <codecell>


# <markdowncell>

# ____

# <headingcell level=2>

# Was passiert, wenn wir in die Implementation der Klasse einen Fehler einbauen?

# <markdowncell>

# Wir verwenden hier, wie schon oben bei der ```checkRep``` Funktion, eine Technik mit dem Namen **Monkey Patching** um eine Funktion in einer Klasse durch eine andere zu ersetzten.

# <codecell>

def enqueue_with_error(self, x):
    if self.size == self.max:
        return False
    self.data[self.tail] = x
    self.size += 1
    self.tail += 1
    if self.tail == self.max:
        self.tail = 1           # <--- Hier stand vorher "= 0"
    return True

# Hier wird jetzt Monkey Patching angewendet.
MyQueue.enqueue = enqueue_with_error

# <markdowncell>

# Auch der ```checkRep``` Funktion geben wir etwas mehr Aussagekraft:

# <codecell>

def checkRep_extended(self):
    assert self.size >= 0 and self.size <= self.max

    if self.tail > self.head:
        assert (self.tail - self.head) == self.size
    
    if self.tail < self.head:
        assert (self.head - self.tail) == (self.max - self.size)
    
    if self.tail == self.head:
        assert (self.size == 0) or (self.size == self.max)

# Auch hier wird wieder Monkey Patching angewendet.
MyQueue.checkRep = checkRep_extended

# <codecell>

test1()

# <codecell>

test2()

# <codecell>

test3()

# <codecell>


