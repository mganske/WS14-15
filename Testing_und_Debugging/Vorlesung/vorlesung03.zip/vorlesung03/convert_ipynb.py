#!/usr/bin/env python3
############################################################## Python FILE ####
"""
    COPYRIGHT (C) 2014 by Sebastian Stigler

    NAME
        convert_ipynb.py -- convert IPython Notebook format for virtual machine

    FIRST RELEASE
        2014-10-17  Sebastian Stigler		sebastian.stigler@htw-aalen.de

"""
###############################################################################

import json
import os

for entry in os.listdir('.'):
    if not os.path.isfile(entry) or not entry.endswith('.ipynb'):
        continue
    with open(entry, 'r') as fd:
        data = json.load(fd)
    if 'nbformat' in data and data['nbformat'] == 3:
        data['nbformat'] = 2
        with open(entry, 'w') as fd:
            json.dump(data, fd, sort_keys=True, indent=1)
        print("    Converted: %s" % entry)
    else:
        print("Not Converted: %s" % entry)


###################################################################### END ####
# vim: ft=python ts=4 sta sw=4 et ai
