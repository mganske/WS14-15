def foo(x, y):
    if x == 0:
        y += 1
    if y == 0:
        x += 1