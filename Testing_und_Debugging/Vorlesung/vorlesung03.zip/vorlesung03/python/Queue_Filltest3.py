from MyQueue import MyQueue

q = MyQueue(1)
r1 = q.empty()
assert r1
r2 = q.full()
assert not r2
