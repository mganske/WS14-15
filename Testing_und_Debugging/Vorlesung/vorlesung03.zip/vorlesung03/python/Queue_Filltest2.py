from MyQueue import MyQueue

q = MyQueue(1)
r1 = q.enqueue(2)
assert r1
r2 = q.enqueue(3)
assert not r2
r3 = q.dequeue()
assert r3 == 2
r4 = q.dequeue()
assert r4 is None

