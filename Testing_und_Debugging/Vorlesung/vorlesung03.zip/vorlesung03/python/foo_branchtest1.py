from foo import foo

foo(0, -1)