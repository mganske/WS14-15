from MyQueue import MyQueue

q = MyQueue(3)
r1 = q.enqueue(5)
assert r1
r2 = q.enqueue(9)
assert r2
r3 = q.dequeue()
assert r3 == 5
r4 = q.dequeue()
assert r4 == 9
