from foo import foo

foo(10, -1)