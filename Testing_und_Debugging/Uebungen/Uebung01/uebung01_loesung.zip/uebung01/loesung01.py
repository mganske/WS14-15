#!/usr/bin/env python3
###############################################################################
## vim: et ai ts=4
##
## Bitte erst ab der Stelle im Code, die mit 'Hier beginnt Ihr Code' markiert
## ist, eigenen Code einfuegen.

###############################################################################

Aufgabe = 1                    # Diesen Eintrag nicht veraendern,
                               # anderenfalls wird die Aufgabe nicht gewertet!!

Studenten = []                 # Initalisierung der Studentenliste

###############################################################################
## Bitte tragen Sie in die folgenden Variablen Ihre Gruppennummer und die
## Mitglieder Ihrer Gruppe ein. Bitte verwenden Sie KEINE Umlaute!

Gruppennummer = 99
# Syntax fuer die Angabe der Namen und Matrikelnummern der einzelen
# Gruppenmitglieder:
#
Studenten.append({'matnr': 99999, 'nachname': "Stigler", 'vorname': "Sebastian"})

###############################################################################
## Laden der Blackboximplementierung der Queue Klasse

from Queue import *
#from Queue import Queue4 as Queue

## SPEZIFIKATION:
##
## Die Queue Klasse stellt eine FIFO Warteschlange mit fester Laenge
## fuer Integes bereit.
##
## Der Konstruktor hat eine Parameter: ein Integer > 0 der die maximale
## Anzahl von Elementen angibt, die die Warteschlange speichern kann.
##
## empty() gibt genau dann True zurueck, wenn die Warteschlange keine
## Elemnte enthaelt.
##
## full() gibt genau dann True zurueck, wenn die Warteschlange kein
## weiters Element speichen kann
##
## enqueue(i) versucht den Integerwert i in der Warteschlange abzulegen.
## Die Funktion gibt True zurueck, falls dieser Versuch erfolgreich war
## und False wenn die Warteschlange voll ist.
##
## dequeue() entfernt (nach dem FIFO Prinzip) eine Wert aus der
## Warteschlange und gibt diesen zurueck. Ist die Warteschlange leer,
## so wird None zuruek gegeben.
##
## Beispiel:
## q = Queue(1)
## is_empty = q.empty()
## succeeded = q.enqueue(10)
## is_full = q.full()
## value = q.dequeue()
##
## Diese Folge von Befehlen sollte folgendes leisten
## 1. Sollte eine Warteschlange q erzeugen, die ein Element speichern kann.
## 2. Sollte pruefen, ob q leer ist. (Erwarte True als Rueckgabewert)
## 3. Sollte versuchen die Zahl 10 in Warteschlange einzutragen. (Erwarte
##    True als Rueckgabewert)
## 4. Sollte testen, ob die Warteschlange voll ist. (Erwarte True als
##    Rueckgabewert)
## 5. Sollte versuchen ein Element aus der Warteschlange zurueckzugeben.
##    (Erwarte 10 als Rueckgabewert)


###############################################################################
## Hier beginnt die Loesung
def testQueue():
    for SIZE in [1, 2, 2 ** 8 + 1]:
        q = Queue(SIZE)
        vglq = []
        for rnd in [1, 2]:
            for x in range(SIZE + 1):
                is_empty = q.empty()
                is_full = q.full()
                assert is_empty == (len(vglq) == 0), "%i. Fill: q SIZE=%i, x=%i, len(vglq)=%i, is_empty == (len(vglq)==0)" % (rnd, SIZE, x, len(vglq))
                assert is_full == (len(vglq) == SIZE), "%i. Fill: q SIZE=%i, x=%i, len(vglq)=%i, is_full == (len(vglq)==SIZE)" % (rnd, SIZE, x, len(vglq))
                if rnd == 2:
                    val = -x
                else:
                    val = x
                enq = q.enqueue(val)
                if len(vglq) < SIZE:
                    fill_ok = True
                    vglq.append(val)
                else:
                    fill_ok = False
                assert enq == fill_ok, "%i. Fill: q SIZE=%i, x=%i, len(vglq)=%i,enq=%s, fill_ok=%s, enq == fill_ok" % (rnd, SIZE, x, len(vglq), str(enq), str(fill_ok))

            for x in range(SIZE + 1):
                is_empty = q.empty()
                is_full = q.full()
                assert is_empty == (len(vglq) == 0), "%i. Clear: q SIZE=%i, x=%i, len(vglq)=%i, is_empty == (len(vglq)==0)" % (rnd, SIZE, x, len(vglq))
                assert is_full == (len(vglq) == SIZE), "%i. Clear: q SIZE=%i, x=%i, len(vglq)=%i, is_full == (len(vglq)==SIZE)" % (rnd, SIZE, x, len(vglq))
                deq = q.dequeue()
                if len(vglq) > 0:
                    vgl = vglq.pop(0)
                else:
                    vgl = None
                assert deq == vgl, "%i. Clear: q SIZE=%i, x=%i, len(vglq)=%i, deq=%s, vgl=%s, deq == vgl" % (rnd, SIZE, x, len(vglq), str(deq), str(vgl))


###############################################################################
## Bitte erst innerhalb des folgenden if Blocks Funktionen aufrufen.
## Werden ausserhalb dieses Blocks Funktionen aufgerufen, so wird die Aufgabe
## nicht gewertet.

if __name__ == '__main__':

    ## Der folgende Funktionsaufruf prueft die Eintraege der Variablen
    ## Studenten, Gruppennummer und Aufgabe und gibt die Werte tabelarisch
    ## auf dem Bildschirm aus oder loest einen Fehler aus, falls die Form
    ## der Eintraege nicht korrekt ist.
    from Grading.Grading import *
    Grading.CheckStudents(Studenten, Gruppennummer, Aufgabe)

    ## Aufruf der Testfunktion
    testQueue()
