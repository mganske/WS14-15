#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <float.h>

/* DBL_EPSILON ist in float.h definiert und hat die Eigenschaft, dass, wenn man
 * mit der Genauigkeit double rechnet folgendes gilt:
 * 
 * (1 + DBL_EPSILON != 1) && (1 + (DBL_EPSILON / 2) == 1)
 */

double mysqrt(double x) {
  /* Vorbedingung */
  assert((x >= 0) && "Radikant muss positiv (oder gleich Null) sein.");

  double result = sqrt(x);

  /* Nachbedingung */
  assert((result * result - x < DBL_EPSILON) && \
         (x - result * result < DBL_EPSILON) && \
         "Das Quadrat des Ergebnisses ist gleich dem Eingabewert.");

  return result;
}

int main() {
  double input = 2.44140625;
  double output;
  int i;

  for (i = 0; i < 10; i++)
  {
    output = mysqrt(input);
    printf("Die Wurzel aus %.16f ist %.16f.\n", input, output);
    input = output;
  }
  return 0;
}
