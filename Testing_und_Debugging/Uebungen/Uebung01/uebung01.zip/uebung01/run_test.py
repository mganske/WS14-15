#!/usr/bin/env python3
###############################################################################
## vim: et ai ts=4
##

###############################################################################
## Laden der Grading Funktionen und setzen der allgemeinen Variablen
##
from Grading.Grading import *

G = Grading
result = []

###############################################################################
## Setzen der Aufgaben-spezifischen Variablen
##
masterresult = [True for i in range(10)]
txtresult = []

toTestPatterns = ["^\s*def\s+testQueue\(\)"]
allowedStructuresPatterns = ["^from\s+Queue\s+import\s+\*\s*$"]

TestClasses = ["Queue", "Queue1", "Queue2", "Queue3", "Queue4", "Queue5", "Queue6", "Queue7", "Queue8"]
swapLinePattern = allowedStructuresPatterns[0]

###############################################################################
## Einlesen der Komandozeile
##
args = G.ParseCMD()

###############################################################################
## Parsen des einzulesend Codes
##
parsedCode = G.ParseCode(args.implfiles[0])

###############################################################################
## Pruefe Eingangsvoraussetzung:
## - Studenten und Gruppennummern Variable ist richtg gesetzt
## - Es werden ausserhalb von 'if __name_== ...' keine Funktionen aufgerufen
##   (AUSNAME: Studenten.append)
## - Es wurden keine zusaetzlichem Module geladen
## - Die zu testenden Strukturen existieren
##
passed_pretest = G.PreTest(parsedCode, toTestPatterns, allowedStructuresPatterns, (args.quiet > 0))

result.append (passed_pretest)
txtresult.append("Vortest")
swapLine = G.FindLines(swapLinePattern, parsedCode['codelines'])

###############################################################################
## Vortest bestanden?
##
if passed_pretest and len(swapLine) == 1:
    codelines = parsedCode['codelines'][:]
    codelines.append("Queue.reset()\n")
    codelines.append("testQueue()\n")

    swapLineIndent = parsedCode['indentprofile']['indent'][swapLine[0]]
    for classnr in range(len(TestClasses)):
        replLine ="%sfrom Queue import %s as Queue\n" %(swapLineIndent, TestClasses[classnr])
        ## Codeinjection 
        codelines[swapLine[0]] = replLine
        my_globals = {}
        try:
            exec(''.join(codelines),my_globals)
            ## ohne Fehler darf nur der 1. Durchgang laufen:
            result.append(classnr==0  # First Class is the good implementation!
                          and min(my_globals['Queue'].called.values()) > 0 # All methodes called 
                          and my_globals['Queue'].error == 0 # No errors occured
                         )
            txtresult.append("Keine Assertion!")
        except AssertionError as err:
            # Catch an AssertionError
            result.append(classnr!=0 and my_globals['Queue'].error > 0)
            txtresult.append("Assertion: %s"%(err))
        except Exception as err:
            # something fishy happened
            result.append(None)
            txtresult.append("Unerwarteter Fehler: %s"%(err))

###############################################################################
## Auswerten des Ergebnisses
##
G.CheckResult(result, masterresult, txtresult, allowLessResults=True, printresult=(args.quiet == 0))
