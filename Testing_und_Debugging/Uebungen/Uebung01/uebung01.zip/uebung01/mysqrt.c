#include <stdio.h>
#include <math.h>
#include <assert.h>

double mysqrt(double x) {

  /* Vorbedingung */

  double result = sqrt(x);

  /* Nachbedingung */
  assert((result * result == x) && \
         "Das Quadrat des Ergebnisses ist gleich dem Eingabewert.");

  return result;
}

int main() {
  double input = 2.44140625;
  double output;
  int i;

  for (i = 0; i < 10; i++)
  {
    output = mysqrt(input);
    printf("Die Wurzel aus %.16f ist %.16f.\n", input, output);
    input = output;
  }
  return 0;
}
