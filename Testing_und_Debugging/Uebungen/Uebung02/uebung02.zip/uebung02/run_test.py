#!/usr/bin/env python3
###############################################################################
## vim: et ai ts=4
##

###############################################################################
## Laden der Grading Funktionen und setzen der allgemeinen Variablen
##
from Grading.Grading import *
import subprocess

G = Grading
result = []

###############################################################################
## Setzen der Aufgaben-spezifischen Variablen
##
masterresult = [True for i in range(10)]
txtresult = []

toTestPatterns = ["."]
allowedStructuresPatterns = ["."]

###############################################################################
## Einlesen der Komandozeile
##
args = G.ParseCMD()

###############################################################################
## Parsen des einzulesend Codes
##
parsedCode = G.ParseCode(args.implfiles[0])

###############################################################################
## Pruefe Eingangsvoraussetzung:
## - Studenten und Gruppennummern Variable ist richtg gesetzt
## - Es werden ausserhalb von 'if __name_== ...' keine Funktionen aufgerufen
##   (AUSNAME: Studenten.append)
## - Es wurden keine zusaetzlichem Module geladen
## - Die zu testenden Strukturen existieren
##
passed_pretest = G.PreTest(parsedCode,
                           toTestPatterns,
                           allowedStructuresPatterns,
                           (args.quiet > 0))

result.append(passed_pretest)
txtresult.append("Vortest")

###############################################################################
## Vortest bestanden?
##
if passed_pretest:
    testfile = "test.txt"
    compfile = args.implfiles[0].split(".")[0]
    if not os.path.isfile(compfile):
        raise IOError("Fehler: %s wurde noch nicht kompiliert." %
                      (compfile + ".c"))

    text = open(testfile, "r").readline()
    for d in [2, 3, 5, 7, 10, 20, 30, 52, 152]:

        res = subprocess.Popen("./%s %s %d" % (compfile, testfile, d),
                           shell=True,  stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE)
        res.wait()

        output = []
        for line in res.stdout.readlines():
            output.append(line.decode("utf-8").strip())

        erroroutput = []
        for line in res.stderr.readlines():
            erroroutput.append(line.decode("utf-8").strip())

        if len(erroroutput) == 0:
            raise Exception(
                        "Fehler: %s wurde ohne '-Wl,--wrap=read' kompiliert." %
                         (compfile))
        if len(output) == 0:
            result.append(None)
            txtresult.append("Keine Ausgabe für './%s %s %d'." % (compfile,
                                                                  testfile, d))
        else:
            if output[0] == text[:min(d, len(text))].strip():
                result.append(True)
                txtresult.append("Vergleich ok")
            else:
                result.append(False)
                txtresult.append("Vergleich nicht ok")


###############################################################################
## Auswerten des Ergebnisses
##
G.CheckResult(result,
              masterresult,
              txtresult,
              allowLessResults=True,
              printresult=(args.quiet == 0))
