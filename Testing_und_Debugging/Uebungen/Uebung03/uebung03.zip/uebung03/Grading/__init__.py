__all__ = ["Grading"]
import sys
if sys.version_info[0] != 3:
	raise Exception("Programm muss mit python3 ausgefuehrt werden!")
